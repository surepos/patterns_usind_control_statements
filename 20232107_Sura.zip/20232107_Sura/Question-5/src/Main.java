import java.util.Scanner;
//This code works perfectly for every even number input
public class Main {
    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);
        System.out.print("Enter the number of lines to print a pattern: ");
        int lineNumber = myScanner.nextInt();

        for (int i = 1; i <= lineNumber; i++) {
            int limit = (i <= lineNumber / 2) ? i : lineNumber - i;
            for (int j = 0; j < (lineNumber - 2 * limit) / 2; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < 2 * limit - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);
        int lineNumber;
        System.out.print("Enter the number lines to print a pattern: ");
        lineNumber = myScanner.nextInt();
        for (int i = 0; i < lineNumber; i++) {
            for (int j = 1; j < lineNumber + 1; j++) {
                System.out.print(j + i);
            }
            System.out.println();
        }
    }
}
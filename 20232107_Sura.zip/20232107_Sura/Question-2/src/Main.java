import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);
        int lineNumber;
        System.out.print("Enter the number lines: ");
        lineNumber = myScanner.nextInt();
        for (int i = lineNumber; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}